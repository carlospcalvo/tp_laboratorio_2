﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Calculadora de Carlos Calvo Nazábal del curso 2°A";
            Numero a = new Numero("123");
            Numero b = new Numero(7);
            Numero c = new Numero("10");
            Numero d = new Numero(0);
            Numero e = new Numero(2);

            double suma;
            double resta;
            double producto;
            double cociente;

            suma = Calculadora.Operar(a, b, "p");
            resta = Calculadora.Operar(c, b, "-");
            producto = Calculadora.Operar(c, e, "*");
            cociente = Calculadora.Operar(c, d, "/");
            
            Console.WriteLine("123 + 7 = {0}", suma);
            Console.WriteLine("10 - 7 = {0}", resta);
            Console.WriteLine("10 * 2 = {0}", producto);
            Console.WriteLine("10 / 0 = {0}", cociente);
            Console.ReadKey();
            
            /*
            //Console.WriteLine(b.DecimalBinario("31"));
            //Console.WriteLine(b.DecimalBinario("asd"));
            Console.WriteLine(b.DecimalBinario(148));
            Console.WriteLine(a.BinarioDecimal("10101"));
            Console.WriteLine(a.BinarioDecimal("001"));
            Console.WriteLine(a.BinarioDecimal("12101"));
            */
        }
    }
}
